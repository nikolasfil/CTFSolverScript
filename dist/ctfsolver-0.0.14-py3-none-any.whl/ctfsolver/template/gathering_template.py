from ctfsolver import CTFSolver


class Gathering(CTFSolver):
    def gathering(self):
        pass
