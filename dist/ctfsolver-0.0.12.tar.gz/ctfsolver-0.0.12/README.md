How to install the project

```bash
python setup.py bdist_wheel sdist
```

For local installation use:

```bash
pip install .
```
