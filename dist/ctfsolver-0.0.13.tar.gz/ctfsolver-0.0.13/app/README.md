Python Solver

More documentation in the [docs](docs/) folder.
