"""
This file is still under development, as the Evtx library has been flagged for security issues.
"""

# import Evtx.Evtx as evtx


class ManagerFileEvtx:
    def __init__(self, *args, **kwargs):
        pass

    def initializing_all_ancestors(self, *args, **kwargs):
        """
        Description:
            Initializes all the ancestors of the class
        """
        pass
